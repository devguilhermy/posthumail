<?php //include "host.php"
    $host = "//" . $_SERVER['HTTP_HOST'] . "/posthumail/"
?>
<link rel="stylesheet" href="<?php echo $host ?>css/bootstrap.css">
<link rel="stylesheet" href="<?php echo $host ?>css/style.css">