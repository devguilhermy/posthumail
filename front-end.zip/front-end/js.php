<?php //include "host.php"
    $host = "//" . $_SERVER['HTTP_HOST'] . "/posthumail/"
?>
<script type="text/javascript" src="<?php echo $host ?>js/jquery-2.2.3.js"></script>
<script type="text/javascript" src="<?php echo $host ?>js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo $host ?>js/common.js"></script>