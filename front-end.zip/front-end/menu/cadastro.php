<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include "../css.php";
    ?>
</head>

<body>
    <?php
    include "navbar.php";
    ?>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="row">
                    <div class="form-group">
                        Nome:
                        <input type="text" class="form-control">
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<?php
include "../js.php";
?>

</html>