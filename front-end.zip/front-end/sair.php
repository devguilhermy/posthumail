<?php
    echo "Você foi deslogado!";
?>